<div class="uc_overlay_image_carousel" id="{{uc_id}}-wrapper">
   <div class="uc_carousel owl-carousel owl-theme uc-items-wrapper {{remote_parent.class}}{{uc_filtering_addclass}} {{uc_dynamic_popup_class}}" data-custom-sethtml="true" {{uc_filtering_attributes|raw}} data-id="{{data_id}}" id="{{uc_id}}" {{remote_parent.attributes|raw}}>
   		{{put_items()}}
   </div>	
</div>

{% if show_empty_message == "true" %}
{% if uc_num_items == 0 %}
  <div class="ue-no-posts-found">{{no_posts_found|raw}}</div>
{% endif %}
{% endif %}